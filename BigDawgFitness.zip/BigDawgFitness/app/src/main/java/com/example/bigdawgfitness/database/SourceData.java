package com.example.bigdawgfitness.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
;import com.example.bigdawgfitness.object.WeekPeriod;

public class SourceData {

    private SQLiteDatabase database;
    private final MySQLiteHelper dbHelper;
    private final String[] allColumns = {MySQLiteHelper.COLUMN_ID,
            MySQLiteHelper.COLUMN_MONDAY,
            MySQLiteHelper.COLUMN_TUESDAY,
            MySQLiteHelper.COLUMN_WEDNESDAY,
            MySQLiteHelper.COLUMN_THURSDAY,
            MySQLiteHelper.COLUMN_FRIDAY,
            MySQLiteHelper.COLUMN_SATURDAY,
            MySQLiteHelper.COLUMN_SUNDAY,
            MySQLiteHelper.COLUMN_OBJECTIVE,
            MySQLiteHelper.COLUMN_MAX};

    public SourceData(Context context) {
        dbHelper = new MySQLiteHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void insert(WeekPeriod weekPeriod) {
        ContentValues values = new ContentValues();
        values.put(MySQLiteHelper.COLUMN_MONDAY, weekPeriod.getMonday());
        values.put(MySQLiteHelper.COLUMN_TUESDAY, weekPeriod.getTuesday());
        values.put(MySQLiteHelper.COLUMN_WEDNESDAY, weekPeriod.getWednesday());
        values.put(MySQLiteHelper.COLUMN_THURSDAY, weekPeriod.getThursday());
        values.put(MySQLiteHelper.COLUMN_FRIDAY, weekPeriod.getFriday());
        values.put(MySQLiteHelper.COLUMN_SATURDAY, weekPeriod.getSaturday());
        values.put(MySQLiteHelper.COLUMN_SUNDAY, weekPeriod.getSunday());
        values.put(MySQLiteHelper.COLUMN_OBJECTIVE, weekPeriod.getObjective());
        values.put(MySQLiteHelper.COLUMN_MAX, weekPeriod.getMax());

        long insertId = database.insert(MySQLiteHelper.TABLE_WEEK, null, values);
    }

    public void delete(WeekPeriod weekPeriod) {
        String selection = MySQLiteHelper.COLUMN_ID + "=?";
        String[] selectionArgs = {weekPeriod.getId() + ""};
        int deleteRows = database.delete(MySQLiteHelper.TABLE_WEEK, selection, selectionArgs);
    }

    public void deleteAll() {
        int deleteRows = database.delete(MySQLiteHelper.TABLE_WEEK, null, null);
    }

    private WeekPeriod cursorToWeek(Cursor cursor) {
        WeekPeriod weekPeriod = new WeekPeriod(cursor.getLong(0),
                cursor.getInt(1),
                cursor.getInt(2),
                cursor.getInt(3),
                cursor.getInt(4),
                cursor.getInt(5),
                cursor.getInt(6),
                cursor.getInt(7),
                cursor.getInt(8),
                cursor.getInt(9));

        return weekPeriod;
    }

    public WeekPeriod getWeek() {
        WeekPeriod ris;
        Cursor cursor = database.query(MySQLiteHelper.TABLE_WEEK,
                allColumns, null, null, null
                , null, null);
        cursor.moveToFirst();
        ris = cursorToWeek(cursor);
        cursor.close();
        return ris;
    }

}