package com.example.bigdawgfitness;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bigdawgfitness.object.WeekPeriod;
import com.example.bigdawgfitness.database.SourceData;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class PressupStatsActivity extends AppCompatActivity {

    BarChart barChart;
    TextView home;

    SourceData tds;
    WeekPeriod thisWeekPeriod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pressupstats);
        home=findViewById(R.id.go_home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gohome=new Intent(PressupStatsActivity.this,Dashboard.class);
                startActivity(gohome);
            }
        });

        createChart();
    }
    private void openDbConnection() {
        tds = new SourceData(this);
        tds.open();
        thisWeekPeriod = tds.getWeek();
        tds.close();
        System.out.println(thisWeekPeriod);
    }

    private void createChart() {

        openDbConnection();

        barChart = (BarChart) findViewById(R.id.barChart);

        barChart.setDrawBarShadow(false);
        barChart.setDrawValueAboveBar(true);
        barChart.setMaxVisibleValueCount(thisWeekPeriod.max);
        barChart.setPinchZoom(false);
        barChart.setDrawGridBackground(false);

        ArrayList<BarEntry> barEntries = new ArrayList<>();
        barEntries.add(new BarEntry(1, thisWeekPeriod.getMonday() * 1f));
        barEntries.add(new BarEntry(2, thisWeekPeriod.getTuesday() * 1f));
        barEntries.add(new BarEntry(3, thisWeekPeriod.getWednesday() * 1f));
        barEntries.add(new BarEntry(4, thisWeekPeriod.getThursday() * 1f));
        barEntries.add(new BarEntry(5, thisWeekPeriod.getFriday() * 1f));
        barEntries.add(new BarEntry(6, thisWeekPeriod.getSaturday() * 1f));
        barEntries.add(new BarEntry(7, thisWeekPeriod.getSunday() * 1f));

        BarDataSet barDataSet = new BarDataSet(barEntries, "This week progress");
        barDataSet.setColors(ColorTemplate.COLORFUL_COLORS);


        BarData data = new BarData(barDataSet);
        data.setBarWidth(0.6f);

        barChart.setData(data);

        String[] months = new String[]{"", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "", ""};
        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new XAxisValues(months));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setCenterAxisLabels(false);

        YAxis yAxis = barChart.getAxisLeft();
        yAxis.setAxisMinimum(0);
        yAxis.setGranularity(1f);

        yAxis = barChart.getAxisRight();
        yAxis.setEnabled(false);

        Description description = new Description();
        description.setText("");

        barChart.setDescription(description);

    }

    public class XAxisValues extends ValueFormatter implements IAxisValueFormatter {

        private String[] nValues;

        public XAxisValues(String[] nValues) {
            this.nValues = nValues;
        }

        @Override
        public String getFormattedValue(float value, AxisBase axis) {
            return nValues[(int) value];
        }
    }


}
