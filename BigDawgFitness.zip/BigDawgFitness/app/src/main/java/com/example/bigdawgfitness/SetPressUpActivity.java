package com.example.bigdawgfitness;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.bigdawgfitness.object.WeekPeriod;
import com.example.bigdawgfitness.database.SourceData;


public class SetPressUpActivity extends AppCompatActivity {

    CardView card_view_saveEdit;
    ImageView increase, decrease;
    TextView txt_work_quantity;

    int actualWork;

    final int CONST_LEVEL_VAR = 5;

    WeekPeriod thisWeekPeriod;
    SourceData tsd;

    SharedPreferences preferences;
    boolean firstToSetWork;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setpressup);

        tsd = new SourceData(this);
        tsd.open();
        thisWeekPeriod = tsd.getWeek();
        actualWork = thisWeekPeriod.objective;
        tsd.close();

        card_view_saveEdit = findViewById(R.id.card_view_saveEdit);
        txt_work_quantity = findViewById(R.id.txt_work_quantity);
        increase = findViewById(R.id.img_increase_work);
        decrease = findViewById(R.id.img_decrease_work);

        setActualWork();

        increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actualWork = actualWork + CONST_LEVEL_VAR;
                setActualWork();
            }
        });

        decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (actualWork > CONST_LEVEL_VAR) {
                    actualWork = actualWork - CONST_LEVEL_VAR;
                    setActualWork();
                } else {
                    toastMessage("You have to do at least 5 press ups!");
                }
            }
        });

        card_view_saveEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tsd.open();
                tsd.delete(thisWeekPeriod);
                thisWeekPeriod.setObjective(actualWork);
                tsd.insert(thisWeekPeriod);
                tsd.close();

                preferences = getSharedPreferences("prefs", MODE_PRIVATE);
                firstToSetWork = preferences.getBoolean("firstToSetWork", true);

                if (firstToSetWork) {
                    goToWorkout();
                }
                finish();
            }
        });

    }

    private void goToWorkout() {
        Intent intent = new Intent(SetPressUpActivity.this, PressupActivity.class);
        startActivity(intent);
        preferences = getSharedPreferences("prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("firstToSetWork", false);
        editor.apply();
        toastMessage("Do your first press ups workout!");
    }

    public void toastMessage(String msg) {
        Context context = getApplicationContext();
        CharSequence text = msg;
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }

    private void setActualWork() {
        txt_work_quantity.setText(actualWork + "");
    }
}
