package com.example.bigdawgfitness;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bigdawgfitness.object.WeekPeriod;
import com.example.bigdawgfitness.database.SourceData;


@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity {

    private static int SPLASH_TIME_OUT = 3000;

    SharedPreferences preferences;
    boolean first, db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                preferences = getSharedPreferences("prefs", MODE_PRIVATE);
                first = preferences.getBoolean("firstStart", true);
                db = preferences.getBoolean("firstDB", true);

                if (db) {

                    initializeDB();
                }

                if (first) {
                    toRegister();
                } else {
                    toLogin();
                }
                finish();
            }
        }, SPLASH_TIME_OUT);
    }

    private void initializeDB() {
        SourceData tds = new SourceData(this);
        tds.open();
        tds.insert(new WeekPeriod());
        tds.close();

        preferences = getSharedPreferences("prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("firstDB", false);
        editor.apply();
    }

    public void toRegister() {
        Intent intent = new Intent(SplashActivity.this, RegisterActivity.class);
        startActivity(intent);

        preferences = getSharedPreferences("prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("firstStart", false);
        editor.apply();
    }

    public void toLogin() {
        Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
        startActivity(intent);
    }
}
