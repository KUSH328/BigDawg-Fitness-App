package com.example.bigdawgfitness;

import android.content.Intent;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bigdawgfitness.object.WeekPeriod;
import com.example.bigdawgfitness.database.SourceData;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.Calendar;

public class Dashboard extends AppCompatActivity {

    ImageView image_info;
    CardView card_view_work, card_view_set_work, card_view_statistics;
    TextView pushUpsQuantity, toDoQuantity, toDoLayer;

    int today, pushs, objective, max, extra;

    final int WORKACTIVITYCODE = 1, SETWORKACTIVITYCODE = 2;

    SourceData tds;
    WeekPeriod thisWeekPeriod;

    PieChart pieChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        image_info = findViewById(R.id.image_info);
        image_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this, TuteActivity.class);
                startActivity(intent);
            }
        });


        card_view_work = findViewById(R.id.card_view_work);
        card_view_work.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this, PressupActivity.class);
                startActivityForResult(intent, WORKACTIVITYCODE);
            }
        });


        card_view_set_work = findViewById(R.id.card_view_setWork);
        card_view_set_work.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this, SetPressUpActivity.class);
                startActivityForResult(intent, SETWORKACTIVITYCODE);
            }
        });

        card_view_statistics = findViewById(R.id.card_view_statistics);
        card_view_statistics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this, PressupStatsActivity.class);
                startActivity(intent);
            }
        });


        pushUpsQuantity = findViewById(R.id.pushUpsQuantity);
        toDoQuantity = findViewById(R.id.toDoQuantity);
        toDoLayer = findViewById(R.id.toDolayer);
        pieChart = findViewById(R.id.piechart);

        setUpdate();
    }

    private void openDbConnection() {
        tds = new SourceData(this);
        tds.open();
        thisWeekPeriod = tds.getWeek();
        tds.close();
    }

    private void setUpdate() {
        openDbConnection();
        Calendar calendar = Calendar.getInstance();
        today = calendar.get(Calendar.DAY_OF_WEEK);


        if (today == Calendar.MONDAY) {
            pushs = thisWeekPeriod.getMonday();
        } else if (today == Calendar.TUESDAY) {
            pushs = thisWeekPeriod.getTuesday();
        } else if (today == Calendar.WEDNESDAY) {
            pushs = thisWeekPeriod.getWednesday();
        } else if (today == Calendar.THURSDAY) {
            pushs = thisWeekPeriod.getThursday();
        } else if (today == Calendar.FRIDAY) {
            pushs = thisWeekPeriod.getFriday();
        } else if (today == Calendar.SATURDAY) {
            pushs = thisWeekPeriod.getSaturday();
        } else if (today == Calendar.SUNDAY) {
            pushs = thisWeekPeriod.getSunday();
        }

        objective = thisWeekPeriod.getObjective();
        max = thisWeekPeriod.getMax();

        fixLayout();
    }

    private void fixLayout() {
        pushUpsQuantity.setText(pushs + "");

        if (pushs > objective) {
            extra = pushs - objective;
            toDoLayer.setText("extra");
        } else {
            extra = objective - pushs;
            toDoLayer.setText("to do");
        }
        toDoQuantity.setText(extra + "");

        makeChart();
    }

    private void makeChart() {
        pieChart.setUsePercentValues(false);
        pieChart.getDescription().setEnabled(false);

        pieChart.setExtraOffsets(5, 10, 5, 5);

        pieChart.setDragDecelerationFrictionCoef(0.95f);

        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.setTransparentCircleRadius(61f);

        ArrayList<PieEntry> yValues = new ArrayList<>();

        float lableVal = getDone();
        if (lableVal > 0) yValues.add(new PieEntry(lableVal, "Done"));

        lableVal = getToDo();
        if (lableVal > 0) yValues.add(new PieEntry(lableVal, "To be done"));

        lableVal = getExtraPushs();
        if (lableVal > 0) yValues.add(new PieEntry(lableVal, "Extra"));

        PieDataSet dataSet = new PieDataSet(yValues, "About today");

        pieChart.animateY(2000, Easing.EaseInOutCubic);

        dataSet.setSliceSpace(3f);
        dataSet.setSelectionShift(5f);
        dataSet.setColors(ColorTemplate.createColors(new int[]{Color.argb(255, 46, 125, 50),
                Color.argb(255, 223, 120, 25)
        }));

        PieData data = new PieData((dataSet));
        data.setValueTextSize(10f);
        data.setValueTextColor(Color.BLACK);

        pieChart.setData(data);

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == WORKACTIVITYCODE) || (requestCode == SETWORKACTIVITYCODE)) {
            setUpdate();
        }
    }


    public float getDone() {
        int max = getMaxPush();
        return (pushs * 1f / max) * 100f;
    }

    public float getToDo() {
        int max = getMaxPush();
        return pushs < objective ? (extra * 1f / max) * 100f : 0f;
    }

    public float getExtraPushs() {
        int max = getMaxPush();
        return pushs > objective ? ((extra) * 1f / max) * 100f : 0f;
    }

    public int getMaxPush() {
        int maxPush = 0;
        if (pushs > maxPush) maxPush = pushs;
        if (objective > maxPush) maxPush = objective;
        if (max > maxPush) maxPush = max;
        return maxPush;
    }
}
