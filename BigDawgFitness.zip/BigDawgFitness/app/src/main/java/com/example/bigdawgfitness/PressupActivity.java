package com.example.bigdawgfitness;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;


import com.example.bigdawgfitness.object.WeekPeriod;
import com.example.bigdawgfitness.database.SourceData;

import java.util.Calendar;


public class PressupActivity extends AppCompatActivity implements SensorEventListener {

    TextView textView, txt_goal_layer, txt_record_layer;
    ImageView stats;
    CardView cardViewSave;


    SourceData tds;
    WeekPeriod thisWeekPeriod;

    SensorManager sensorManager;
    Sensor sensor;

    SharedPreferences preferences;
    boolean firstToWork;

    int pushs, objective, max, today;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pressup);

        stats=findViewById(R.id.img_statistics);
        textView = findViewById(R.id.txt_pushUp_counter);
        txt_goal_layer = findViewById(R.id.txt_goal_layer);
        txt_record_layer = findViewById(R.id.txt_personal_record_layer);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);


        tds = new SourceData(this);
        tds.open();
        thisWeekPeriod = tds.getWeek();
        tds.close();

        getTodaysPushUps();

        stats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent toStats=new Intent(PressupActivity.this,PressupStatsActivity.class);
                startActivity(toStats);
            }
        });

        cardViewSave = findViewById(R.id.card_view_save);
        cardViewSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tds.open();
                tds.delete(thisWeekPeriod);
                setTodaysPushUps();
                tds.insert(thisWeekPeriod);
                tds.close();

                goToNext();
            }
        });
    }

    private void goToNext() {
        preferences = getSharedPreferences("prefs", MODE_PRIVATE);
        firstToWork = preferences.getBoolean("firstToWork", true);

        if (firstToWork) {
            goToHome();
        }
        finish();

    }

    private void goToHome() {
        Intent intent = new Intent(PressupActivity.this, Dashboard.class);
        startActivity(intent);

        preferences = getSharedPreferences("prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("firstToWork", false);
        editor.apply();
    }

    private void setTodaysPushUps() {
        if (today == Calendar.MONDAY) {
            thisWeekPeriod.setMonday(pushs);
        } else if (today == Calendar.TUESDAY) {
            thisWeekPeriod.setTuesday(pushs);
        } else if (today == Calendar.WEDNESDAY) {
            thisWeekPeriod.setWednesday(pushs);
        } else if (today == Calendar.THURSDAY) {
            thisWeekPeriod.setThursday(pushs);
        } else if (today == Calendar.FRIDAY) {
            thisWeekPeriod.setFriday(pushs);
        } else if (today == Calendar.SATURDAY) {
            thisWeekPeriod.setSaturday(pushs);
        } else if (today == Calendar.SUNDAY) {
            thisWeekPeriod.setSunday(pushs);
        }
        if (pushs > thisWeekPeriod.getMax()) {
            thisWeekPeriod.setMax(pushs);
        }
    }

    private void getTodaysPushUps() {
        Calendar calendar = Calendar.getInstance();
        today = calendar.get(Calendar.DAY_OF_WEEK);

        if (today == Calendar.MONDAY) {
            pushs = thisWeekPeriod.getMonday();
        } else if (today == Calendar.TUESDAY) {
            pushs = thisWeekPeriod.getTuesday();
        } else if (today == Calendar.WEDNESDAY) {
            pushs = thisWeekPeriod.getWednesday();
        } else if (today == Calendar.THURSDAY) {
            pushs = thisWeekPeriod.getThursday();
        } else if (today == Calendar.FRIDAY) {
            pushs = thisWeekPeriod.getFriday();
        } else if (today == Calendar.SATURDAY) {
            pushs = thisWeekPeriod.getSaturday();
        } else if (today == Calendar.SUNDAY) {
            pushs = thisWeekPeriod.getSunday();
        }


        objective = thisWeekPeriod.getObjective();
        max = thisWeekPeriod.getMax();

        txt_goal_layer.setText("Target : " + objective);
        txt_record_layer.setText("My record: " + max);
        textView.setText(pushs + "");

    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            if (sensorEvent.values[0] == 0.0) {
                pushs++;
            }
            textView.setText(pushs + "");
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
