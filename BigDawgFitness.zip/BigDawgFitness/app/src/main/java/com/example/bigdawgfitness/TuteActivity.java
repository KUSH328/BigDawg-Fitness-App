package com.example.bigdawgfitness;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.example.bigdawgfitness.adapter.Slider;


public class TuteActivity extends AppCompatActivity {

    private ViewPager nSlideViewPager;
    private LinearLayout nDotLayout;

    private Slider sliderAdapter;

    private TextView[] nDots;

    private TextView next;
    private TextView prev;
    private int currentPage;

    SharedPreferences preferences;
    boolean firstToTut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tute);

        nSlideViewPager = (ViewPager) findViewById(R.id.slideViewPager);
        nDotLayout = (LinearLayout) findViewById(R.id.dotsLayout);

        next = findViewById(R.id.t_next);
        prev = findViewById(R.id.t_prev);

        sliderAdapter = new Slider(this);
        nSlideViewPager.setAdapter(sliderAdapter);

        addDotsIndicator(0);

        nSlideViewPager.addOnPageChangeListener(viewListener);


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                preferences = getSharedPreferences("prefs", MODE_PRIVATE);
                firstToTut = preferences.getBoolean("firstToTut", true);

                if (currentPage == 2) {

                    if (firstToTut) {
                        goToSetWork();
                    }
                    finish();
                }
                nSlideViewPager.setCurrentItem(currentPage + 1);
            }
        });

        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nSlideViewPager.setCurrentItem(currentPage - 1);
            }
        });
    }

    private void goToSetWork() {

        Intent intent = new Intent(TuteActivity.this, LoginActivity.class);
        startActivity(intent);

        Toast.makeText(this,"Set your first press up workout target!",Toast.LENGTH_SHORT).show();

        preferences = getSharedPreferences("prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("firstToTut", false);
        editor.apply();
    }

    public void addDotsIndicator(int position) {
        nDots = new TextView[3];
        nDotLayout.removeAllViews();
        for (int i = 0; i < nDots.length; i++) {
            nDots[i] = new TextView(this);
            nDots[i].setText(Html.fromHtml("&#8226;"));
            nDots[i].setTextSize(35);
            nDots[i].setTextColor(getResources().getColor(R.color.transparent));

            nDotLayout.addView(nDots[i]);

        }

        if (nDots.length > 0) {
            nDots[position].setTextColor(getResources().getColor(R.color.colorPrimaryDark));
        }
    }

    ViewPager.OnPageChangeListener viewListener = new ViewPager.OnPageChangeListener() {

        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        public void onPageSelected(int position) {
            addDotsIndicator(position);

            currentPage = position;

            if (position == 0) {
                next.setEnabled(true);
                prev.setEnabled(false);
                prev.setVisibility(View.INVISIBLE);

                next.setText("Next");
                prev.setText("");
            } else if (position == nDots.length - 1) {
                next.setEnabled(true);
                prev.setEnabled(true);
                prev.setVisibility(View.VISIBLE);

                next.setText("Finish");
                prev.setText("Back");
            } else {
                next.setEnabled(true);
                prev.setEnabled(true);
                prev.setVisibility(View.VISIBLE);

                next.setText("Next");
                prev.setText("Back");
            }
        }

        public void onPageScrollStateChanged(int state) {

        }

    };
}
