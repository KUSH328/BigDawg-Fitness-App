package com.example.bigdawgfitness.adapter;

import android.content.Context;
import android.graphics.Color;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import com.example.bigdawgfitness.R;


public class Slider extends PagerAdapter {

    Context context;
    LayoutInflater inflater;

    public int[] slide_images = {
            R.drawable.pressups,
            R.drawable.achievements,
            R.drawable.statistics
    };

    public String[] slide_headings = {
            "Press Ups",
            "Accomplishments",
            "Statistics"
    };

    public String[] slide_descriptions = {
            "BigDawg Fitness offers you another big chance to work your triceps, pectoral muscles, and shoulders virtually anywhere and the good thing is that you don't require any equipment. Using proper form of this app, will help strengthen your lower back and core by engaging (pulling in) the abdominal muscles. Press ups are a fast and effective exercise for building strength.",
            "We're proud to announce that BigDawg Fitness app has helped over 10,000 users improve their push up technique and increase their strength. Our step-by-step tutorials and personalized workout plans have received rave reviews from users, with many reporting significant gains in their push up performance. In addition, our app has been featured in various fitness publications and was a top seller in the Google Play Store. We are excited to continue providing high-quality fitness resources to our clients.",
            "Welcome to BigDawg Fitness app! This app is designed to help you improve your push-up technique and increase the number of push-ups you can do.\\n\n" +
                    "To get started, open the app and select the \"Tute\" image button. Here, you will find detailed instructions on proper push-up form. Pay close attention to the tips and techniques, as proper form is key to maximizing your push-up performance.\\n" +
                    "Once you have mastered the basics, move on to the \"Dashboard\" . Here, you can log your daily push-up workouts, set goals and track your progress over time."
    };

    public Slider(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return slide_headings.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.layout_slider, container, false);

        ImageView slideImage = view.findViewById(R.id.tuts_images);
        TextView slideHeading = view.findViewById(R.id.slide_heading);
        TextView slideDescription = view.findViewById(R.id.slide_description);

        //Images
        slideImage.setImageResource(slide_images[position]);

        //Heading
        slideHeading.setText(slide_headings[position]);
        slideHeading.setTextColor(Color.BLACK);
        slideHeading.setGravity(Gravity.CENTER);

        //Description
        slideDescription.setText(slide_descriptions[position]);
        slideDescription.setTextColor(Color.WHITE);
        slideDescription.setGravity(Gravity.CENTER);

        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((LinearLayout) object);
    }

}
